﻿using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

namespace SistemaGestionTarjetas
{
    class Program
    {
        // Clase que define la estructura de una tarjeta de crédito
        class TarjetaCredito
        {
            public string Numero { get; set; } // Número de la tarjeta de crédito
            public double Saldo { get; set; } // Saldo de la tarjeta de crédito
        }


        // Variables que almacenan las tarjetas, pagos, estados de cuenta y otras informaciones
        static List<TarjetaCredito> tarjetasCredito = new List<TarjetaCredito>(); // Lista de tarjetas de crédito
        static Queue<double> pagos = new Queue<double>(); // Cola de pagos realizados
        // Árbol binario de búsqueda para organizar los estados de cuenta de cada tarjeta
        static Dictionary<string, double> estadosCuenta = new Dictionary<string, double>();
        static Stack<string> transaccionesTarjeta = new Stack<string>(); // Pila de transacciones de tarjeta
        static Queue<string> notificaciones = new Queue<string>(); // Cola de notificaciones
        static LinkedList<string> cambiosPIN = new LinkedList<string>(); // Lista enlazada de cambios de PIN
        static SortedSet<string> tarjetasBloqueadasTemp = new SortedSet<string>(); // Conjunto ordenado de tarjetas bloqueadas temporalmente
        static Stack<string> solicitudesAumentoLimite = new Stack<string>(); // Pila de solicitudes de aumento de límite de crédito
        // Nombre del archivo JSON
        const string archivoJson = "dato_Tarjeta_Credito.json";
        // Método para cargar los datos iniciales desde el archivo JSON
        static void CargarDatosIniciales()
        {
            try
            {
                if (File.Exists(archivoJson))
                {
                    string jsonData = File.ReadAllText(archivoJson);
                    tarjetasCredito = JsonConvert.DeserializeObject<List<TarjetaCredito>>(jsonData);
                    Console.WriteLine("Datos cargados exitosamente desde el archivo JSON.");
                }
                else
                {
                    Console.WriteLine("Archivo de datos inicial no encontrado. Se creará uno nuevo.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al cargar datos iniciales: " + ex.Message);
            }
        }

        // Método para guardar los datos en el archivo JSON
        static void GuardarDatos()
        {
            try
            {
                string jsonData = JsonConvert.SerializeObject(tarjetasCredito, Formatting.Indented);
                File.WriteAllText(archivoJson, jsonData);
                Console.WriteLine("Datos guardados exitosamente en el archivo JSON.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al guardar datos: " + ex.Message);
            }
        }

        // Método para mostrar el menú
        static void MostrarMenu()
        {
            Console.WriteLine("---- MENÚ ----");
            Console.WriteLine("1. Consultar saldo");
            Console.WriteLine("2. Realizar pago");
            Console.WriteLine("3. Generar estado de cuenta");
            Console.WriteLine("4. Consultar movimientos de tarjeta");
            Console.WriteLine("5. Enviar notificación");
            Console.WriteLine("6. Cambiar PIN");
            Console.WriteLine("7. Bloquear tarjeta temporalmente");
            Console.WriteLine("8. Solicitar aumento de límite de crédito");
            Console.WriteLine("9. Salir");
            Console.WriteLine();
            Console.Write("Seleccione una opción: ");
        }

        // Función para obtener el saldo de una tarjeta de crédito
        static double ObtenerSaldo(string numeroTarjeta)
        {
            foreach (var tarjeta in tarjetasCredito)
            {
                if (tarjeta.Numero == numeroTarjeta)
                    return tarjeta.Saldo;
            }
            return -1; // Retorna -1 si la tarjeta no se encuentra
        }

        // Función para generar el estado de cuenta de una tarjeta de crédito
        static void GenerarEstadoCuenta(string numeroTarjeta, double saldo)
        {
            // Verificar si la tarjeta ya tiene un estado de cuenta generado
            if (!estadosCuenta.ContainsKey(numeroTarjeta))
            {
                // Agregar el saldo al árbol binario de búsqueda
                estadosCuenta.Add(numeroTarjeta, saldo);
            }
            else
            {
                Console.WriteLine("El estado de cuenta para esta tarjeta ya ha sido generado.");
            }
        }





        // Método principal
        static void Main(string[] args)
        {
            CargarDatosIniciales();

            bool continuar = true;
            while (continuar)
            {
                MostrarMenu();
                string opcion = Console.ReadLine();
                Console.WriteLine();

                switch (opcion)
                {
                    case "1":
                        Console.Write("Ingrese el número de tarjeta: ");
                        string numeroTarjetaConsulta = Console.ReadLine();
                        double saldo = ConsultarSaldo(numeroTarjetaConsulta);
                        if (saldo != -1)
                            Console.WriteLine($"Saldo actual: {saldo}");
                        else
                            Console.WriteLine("Tarjeta no encontrada.");
                        break;



                    case "2":
                        Console.Write("Ingrese el número de tarjeta para realizar el pago: ");
                        string numeroTarjetaPago = Console.ReadLine();

                        // Verificar si la tarjeta existe antes de continuar
                        var tarjetaPago = tarjetasCredito.Find(t => t.Numero == numeroTarjetaPago);
                        if (tarjetaPago != null)
                        {
                            Console.Write("Ingrese el monto del pago: ");
                            double montoPago;
                            if (double.TryParse(Console.ReadLine(), out montoPago))
                            {
                                Console.WriteLine($"Confirme el pago de {montoPago} a la tarjeta {numeroTarjetaPago}. (S/N)");
                                string confirmacion = Console.ReadLine().ToUpper();

                                if (confirmacion == "S")
                                {
                                    // Agregar el pago a la cola de pagos
                                    RealizarPago(numeroTarjetaPago, montoPago);
                                    Console.WriteLine("Pago agregado a la cola correctamente.");
                                }
                                else
                                {
                                    Console.WriteLine("Pago cancelado.");
                                }
                            }
                            else
                            {
                                Console.WriteLine("Monto inválido.");
                            }
                        }
                        else
                        {
                            Console.WriteLine("La tarjeta no existe.");
                        }
                        break;


                    case "3":
                        Console.Write("Ingrese el número de tarjeta para generar el estado de cuenta: ");
                        string numeroTarjetaEstadoCuenta = Console.ReadLine();
                        double saldoTarjeta = ObtenerSaldo(numeroTarjetaEstadoCuenta);
                        if (saldoTarjeta != -1)
                        {
                            GenerarEstadoCuenta(numeroTarjetaEstadoCuenta, saldoTarjeta);
                            Console.WriteLine("Estado de cuenta generado correctamente.");
                        }
                        else
                        {
                            Console.WriteLine("La tarjeta no existe.");
                        }
                        break;

                    case "4":
                        Console.Write("Ingrese el número de tarjeta para consultar movimientos: ");
                        string numeroTarjetaConsultaMovimientos = Console.ReadLine();
                        Console.WriteLine("Movimientos de tarjeta:");
                        CheckTransactions(numeroTarjetaConsultaMovimientos);
                        break;

                    case "5":
                        Console.Write("Ingrese el mensaje de la notificación: ");
                        string mensajeNotificacion = Console.ReadLine();
                        SendNotification(mensajeNotificacion);
                        break;

                    case "6":
                        Console.Write("Ingrese el número de tarjeta: ");
                        string numTarjetaPIN = Console.ReadLine();
                        Console.Write("Ingrese el nuevo PIN: ");
                        string nuevoPIN = Console.ReadLine();
                        ChangePIN(numTarjetaPIN, nuevoPIN);
                        break;

                    case "7":
                        Console.Write("Ingrese el número de tarjeta: ");
                        string numTarjetaBloqueo = Console.ReadLine();
                        BlockCard(numTarjetaBloqueo);
                        break;

                    case "8":
                        Console.Write("Ingrese el número de tarjeta: ");
                        string numTarjetaLimite = Console.ReadLine();
                        Console.Write("Ingrese el nuevo límite de crédito: ");
                        double nuevoLimite;
                        if (double.TryParse(Console.ReadLine(), out nuevoLimite))
                            RequestCreditLimitIncrease(numTarjetaLimite, nuevoLimite);
                        else
                            Console.WriteLine("Límite de crédito inválido.");
                        break;

                    case "9":
                        continuar = false;
                        Console.WriteLine("¡Hasta luego!");
                        break;

                    default:
                        Console.WriteLine("Opción no válida. Por favor, seleccione una opción del menú.");
                        break;
                }

                Console.WriteLine();
            }

            GuardarDatos();
        }

        // Funciones de las APIs

        // Consulta el saldo de una tarjeta de crédito
        static double ConsultarSaldo(string numeroTarjeta)
        {
            foreach (var tarjeta in tarjetasCredito)
            {
                if (tarjeta.Numero == numeroTarjeta)
                    return tarjeta.Saldo;
            }
            return -1; // Retorna -1 si la tarjeta no se encuentra
        }

        // Realiza un pago a una tarjeta de crédito
        static void RealizarPago(string? numeroTarjetaPago, double monto)
        {
            pagos.Enqueue(monto);
            foreach (var tarjeta in tarjetasCredito)
            {
                if (pagos.Count > 0)
                {
                    double pago = pagos.Dequeue();
                    tarjeta.Saldo -= pago;
                    string movimiento = $"Pago realizado: {pago}";
                    transaccionesTarjeta.Push(movimiento); // Agregar el movimiento a la pila
                }
            }
        }

        // Genera el estado de cuenta de una tarjeta de crédito
        static void GenerarEstadoCuenta(string numeroTarjeta)
        {
            foreach (var tarjeta in tarjetasCredito)
            {
                if (tarjeta.Numero == numeroTarjeta)
                {
                    estadosCuenta[numeroTarjeta] = tarjeta.Saldo;
                    break;
                }
            }
        }

        // Consulta los movimientos realizados con la tarjeta
        static void CheckTransactions(string? numeroTarjetaConsultaMovimientos)
        {
            if (transaccionesTarjeta.Count == 0)
            {
                Console.WriteLine("No hay movimientos disponibles.");
            }
            else
            {
                Console.WriteLine("Últimos movimientos realizados:");
                foreach (var movimiento in transaccionesTarjeta)
                {
                    Console.WriteLine(movimiento);
                }
            }
        }

        // Envía una notificación
        static void SendNotification(string message)
        {
            notificaciones.Enqueue(message);
            Console.WriteLine("Notificación enviada: " + message);
        }

        // Cambia el PIN de una tarjeta de crédito
        static void ChangePIN(string numeroTarjeta, string nuevoPIN)
        {
            cambiosPIN.AddLast($"PIN de tarjeta {numeroTarjeta} cambiado a {nuevoPIN}");
            Console.WriteLine($"PIN de tarjeta {numeroTarjeta} cambiado a {nuevoPIN}");
        }

        // Bloquea temporalmente una tarjeta de crédito
        static void BlockCard(string numeroTarjeta)
        {
            tarjetasBloqueadasTemp.Add(numeroTarjeta);
            Console.WriteLine($"Tarjeta {numeroTarjeta} bloqueada temporalmente.");
        }

        // Solicita un aumento de límite de crédito
        static void RequestCreditLimitIncrease(string numeroTarjeta, double nuevoLimite)
        {
            solicitudesAumentoLimite.Push($"Solicitud de aumento de límite de crédito para tarjeta {numeroTarjeta} a {nuevoLimite}");
            Console.WriteLine($"Solicitud de aumento de límite de crédito para tarjeta {numeroTarjeta} a {nuevoLimite} realizada.");
        }
    }
}

